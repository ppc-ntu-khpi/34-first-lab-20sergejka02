public class Quotation {
  String quote = "Be yourself; everyone else is already taken.   \n – Oscar Wilde";
  public void display() {
    System.out.println(quote);
  }
}
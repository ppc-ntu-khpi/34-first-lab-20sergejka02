cd src
javac *.java
java ShirtTest
java QuotationTest